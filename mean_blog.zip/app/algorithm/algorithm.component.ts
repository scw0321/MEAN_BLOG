import { Component, OnInit } from '@angular/core';
import { HttpService } from '../http.service';
import { Router, ActivatedRoute } from '@angular/router';



@Component({
  selector: 'app-algorithm',
  templateUrl: './algorithm.component.html',
  styleUrls: ['./algorithm.component.css']
})
export class AlgorithmComponent implements OnInit {

  posts: any[] = [];
  // posts: any;
  constructor(private _http: HttpService, private _router: Router, 
    private _route: ActivatedRoute) { }

  ngOnInit() {
    this.posts = [{
      title: "",
      description: "",
      createdAt: ""
    }]

    this._http.getAlg().subscribe((data:any[])=>this.posts = data);
  	
  }
  getAlg()
  {
    this._http.getAlg().subscribe((data:any[])=>this.posts = data);
  }

  // createNew(){
  //   console.log("post a new question")
  // }
 



  
}
